import java.util.Scanner;
public class baitap1_capdo2 {
    public static double tinhThue(double thuNhap) {
        double thue = 0;

        // Mức 1: 0 - 5 triệu (5%)
        if (thuNhap <= 5) {
            thue = thuNhap * 0.05;
        }
        // Mức 2: 5 - 10 triệu (10%)
        else if (thuNhap <= 10) {
            thue = 5 * 0.05
                    + (thuNhap - 5) * 0.10;
        }
        // Mức 3: 10 - 18 triệu (15%)
        else if (thuNhap <= 18) {
            thue = 5 * 0.05
                    + 5 * 0.10
                    + (thuNhap - 10) * 0.15;
        }
        // Mức 4: 18 - 32 triệu (20%)
        else if (thuNhap <= 32) {
            thue = 5 * 0.05
                    + 5 * 0.10
                    + 8 * 0.15
                    + (thuNhap - 18) * 0.20;
        }
        // Mức 5: 32 - 52 triệu (25%)
        else if (thuNhap <= 52) {
            thue = 5 * 0.05
                    + 5 * 0.10
                    + 8 * 0.15
                    + 14 * 0.20
                    + (thuNhap - 32) * 0.25;
        }
        // Mức 6: 52 - 80 triệu (30%)
        else if (thuNhap <= 80) {
            thue = 5 * 0.05
                    + 5 * 0.10
                    + 8 * 0.15
                    + 14 * 0.20
                    + 20 * 0.25
                    + (thuNhap - 52) * 0.30;
        }
        // Mức 7: trên 80 triệu (35%)
        else {
            thue = 5 * 0.05
                    + 5 * 0.10
                    + 8 * 0.15
                    + 14 * 0.20
                    + 20 * 0.25
                    + 28 * 0.30
                    + (thuNhap - 80) * 0.35;
        }

        return thue;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nhập thu nhập hàng năm (triệu đồng): ");
        double thuNhap = scanner.nextDouble();

        if (thuNhap < 0) {
            System.out.println("Thu nhập không hợp lệ!");
        } else {
            double thue = tinhThue(thuNhap);
            System.out.printf("Thu nhập: %.2f triệu đồng%n", thuNhap);
            System.out.printf("Thuế phải trả: %.2f triệu đồng%n", thue);
        }

        scanner.close();
    }


}

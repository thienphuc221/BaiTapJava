import java.util.HashMap;
public class baitap3_capdo3 {
    public static String minWindow(String s, String t) {
        if (s.length() == 0 || t.length() == 0) return "";

        HashMap<Character, Integer> map = new HashMap<>();
        for (char c : t.toCharArray()) {
            map.put(c, map.getOrDefault(c, 0) + 1);
        }

        int left = 0, right = 0;
        int formed = 0;
        int required = map.size();

        HashMap<Character, Integer> window = new HashMap<>();

        int minLen = Integer.MAX_VALUE;
        int start = 0;

        while (right < s.length()) {
            char c = s.charAt(right);
            window.put(c, window.getOrDefault(c, 0) + 1);

            if (map.containsKey(c) &&
                    window.get(c).intValue() == map.get(c).intValue()) {
                formed++;
            }

            // Khi đủ điều kiện → thu nhỏ
            while (left <= right && formed == required) {
                char ch = s.charAt(left);

                // cập nhật kết quả
                if (right - left + 1 < minLen) {
                    minLen = right - left + 1;
                    start = left;
                }

                // bỏ ký tự bên trái
                window.put(ch, window.get(ch) - 1);

                if (map.containsKey(ch) &&
                        window.get(ch) < map.get(ch)) {
                    formed--;
                }

                left++;
            }

            right++;
        }

        return minLen == Integer.MAX_VALUE ? "" : s.substring(start, start + minLen);
    }

    public static void main(String[] args) {
        System.out.println(minWindow("ADOBECODEBANC", "ABC")); // BANC
    }

}

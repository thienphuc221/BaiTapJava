public class bai1_capdo1 {
        public static void main(String[] args) {
            String input = "Hello World";
            String result = xoaNguyenAm(input);

            System.out.println("Chuỗi ban đầu: " + input);
            System.out.println("Chuỗi sau khi xóa nguyên âm: " + result);
        }

        public static String xoaNguyenAm(String str) {
            // Sử dụng StringBuilder để nối chuỗi hiệu quả hơn
            StringBuilder sb = new StringBuilder();

            // Chuyển chuỗi thành mảng ký tự để duyệt
            for (int i = 0; i < str.length(); i++) {
                char c = str.charAt(i);

                // Kiểm tra xem ký tự hiện tại có phải là nguyên âm không
                // Lưu ý: Kiểm tra cả chữ hoa và chữ thường
                if (!isNguyenAm(c)) {
                    sb.append(c);
                }
            }

            return sb.toString();
        }

        // Hàm phụ để kiểm tra một ký tự có phải là nguyên âm hay không
        public static boolean isNguyenAm(char c) {
            char lowerC = Character.toLowerCase(c);
            return lowerC == 'a' || lowerC == 'e' || lowerC == 'i' || lowerC == 'o' || lowerC == 'u';
        }
    }

